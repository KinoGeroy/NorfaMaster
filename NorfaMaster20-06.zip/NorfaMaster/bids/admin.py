from django.contrib import admin

from .models import Bid

admin.site.register(Bid)
