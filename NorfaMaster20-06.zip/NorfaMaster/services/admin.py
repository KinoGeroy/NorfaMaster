from django.contrib import admin

from .models import Service

class CityAdmin(admin.ModelAdmin):
    list_display = ("title", "pk",) # name-название услуги, spec - тег(фильтр)
 


admin.site.register(Service, CityAdmin)
