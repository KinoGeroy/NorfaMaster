from django.contrib import admin

from .models import City
 
class CityAdmin(admin.ModelAdmin):
    list_display = ("name", "spec",) # name-название услуги, spec - тег(фильтр)
 
admin.site.register(City, CityAdmin)