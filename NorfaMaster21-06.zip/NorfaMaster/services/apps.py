from django.apps import AppConfig


class ServicesConfig(AppConfig):
    name = 'services'
    default_auto_field = 'django.db.models.BigAutoField'
    